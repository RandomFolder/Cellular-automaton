#include <iostream>
#include <ctime>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>

class Cell
{
    private:
        sf::Color color;
        sf::Color colors_of_dead_cell[7] = {sf::Color(245, 2, 124), sf::Color(131, 1, 145), sf::Color(24, 173, 184), sf::Color(14, 110, 117), sf::Color(8, 62, 66), sf::Color(4, 31, 33), sf::Color(0, 0, 0)};
        int current_decay_state = 6, decay_timer = 0;
        int color_decay_time[7] = {4, 4, 16, 16, 16, 16, 16};
        bool dead;
        bool states_record[2] = { false, false };
    
    public:
        Cell()
        {
            color = sf::Color::Black;
            dead = true;
            states_record[1] = true;
        }

        Cell(bool Dead)
        {
            dead = Dead;
            states_record[1] = dead;
            dead ? color = sf::Color::Black : color = sf::Color::White;
        }

        sf::Color get_color() { return color; }

        bool is_dead() { return dead; }

        void set_state(bool isDead)
        { 
            dead = isDead;
            std::swap(states_record[0], states_record[1]);
            states_record[1] = dead;
            if (!states_record[0] && states_record[1])
            {
                //color = sf::Color(120, 170, 100);
                current_decay_state = 0;
            }
        }

        void update_color()
        {
            if (dead)
            {
                //if (color.r > 0) color.r -= 1;
                //if (color.b > 0) color.b -= 1;
                //if (color.g > 0) color.g -= 1;
                if (current_decay_state != 6)
                {
                    decay_timer++;
                    if (decay_timer > color_decay_time[current_decay_state])
                    {
                        current_decay_state++;
                        decay_timer = 0;
                    }
                    color = colors_of_dead_cell[current_decay_state];
                }
            }
            else
            {
                color = sf::Color(255, 255, 255);
                current_decay_state = 0;
            }
        }
};

class Automata
{
    public:
        virtual ~Automata() = default;
        virtual void update_field(Cell (&field)[150][200]) = 0;
};

class GameOfLife : public Automata
{
    public:
        void update_field(Cell (&field)[150][200])
        {
            Cell new_field[150][200];

            for (int i = 0; i < 150; i++)
            {
                for (int j = 0; j < 200; j++)
                {
                    int counter = 0;
                    for (int k = -1; k < 2; k++)
                        for (int p = -1; p < 2; p++)
                            if (i + k >= 0 && i + k < 150 && j + p >= 0 && j + p < 200 && !(k == 0 && p == 0) && !field[i + k][j + p].is_dead()) counter++;

                    if (!field[i][j].is_dead() && (counter == 2 || counter == 3)) new_field[i][j].set_state(false);
                    else if (field[i][j].is_dead() && counter == 3) new_field[i][j].set_state(false);
                    else new_field[i][j].set_state(true);
                }
            }

            for (int i = 0; i < 150; i++)
                for (int j = 0; j < 200; j++)
                {
                    field[i][j].set_state(new_field[i][j].is_dead());
                    field[i][j].update_color();
                }
        }
};
/*
class LangtonAnt : public Automata
{
    private:
        int dirX = 1, dirY = 0, posX = 50, posY = 50;

        void TurnRight()
        {
            std::swap(dirX, dirY);
            if (dirY != 0)
            {
                dirX *= -1; dirY *= -1;
            }
        }

        void TurnLeft()
        {
            std::swap(dirX, dirY);
            if (dirX != 0)
            {
                dirX *= -1; dirY *= -1;
            }
        }
    
    public:
        void update_field(bool (&field)[150][200])
        {
            (field[posY][posX]) ? TurnRight() : TurnLeft();
            field[posY][posX] = !field[posY][posX];
            posX += dirX;
            posY += dirY;

            if (posX >= 200) posX = 0;
            if (posX < 0) posX = 199;
            if (posY >= 150) posY = 0;
            if (posY < 0) posY = 149;
        }
};*/


int main()
{
    srand(time(0));

    int pen_size = 1, cursor_pos_x = 0, cursor_pos_y = 0;
    bool paused = true;
    Cell Field[150][200];
    //Automata* current_automata = new LangtonAnt();
    Automata* current_automata = new GameOfLife();

    for (int i = 0; i < 150; i++)
        for (int j = 0; j < 200; j++) Field[i][j] = Cell(true);

    sf::RenderWindow window(sf::VideoMode(800, 600), "Cellular automata", sf::Style::Titlebar | sf::Style::Close);
    window.setFramerateLimit(30);
    window.setMouseCursorVisible(false);

    sf::RectangleShape cursor_outline(sf::Vector2f(pen_size * 4, pen_size * 4));
    cursor_outline.setFillColor(sf::Color::Transparent);
    cursor_outline.setOutlineColor(sf::Color(130, 130, 130));

    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();
            if (event.type == sf::Event::MouseButtonPressed)
            {
                int posX = event.mouseButton.x / 4;
                int posY = event.mouseButton.y / 4;

                for (int i = posY; i < std::min(posY + pen_size, 150); i++)
                    for (int j = posX; j < std::min(posX + pen_size, 200); j++) Field[i][j] = Cell(false);
            }
            if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Enter) paused = !paused;
            if (event.type == sf::Event::MouseWheelScrolled)
            {
                pen_size += event.mouseWheelScroll.delta;
                if (pen_size < 1) pen_size = 1;
                if (pen_size > 70) pen_size = 70;
            }
            if (event.type == sf::Event::MouseMoved)
            {
                cursor_pos_x = event.mouseMove.x / 4;
                cursor_pos_y = event.mouseMove.y / 4;
            }
        }

        if (!paused) current_automata->update_field(Field);

        window.clear();
        
        for (int i = 0; i < 150; i++)
            for (int j = 0; j < 200; j++)
                if (Field[i][j].get_color() != sf::Color::Black)
                {
                    sf::RectangleShape shape(sf::Vector2f(3, 3));
                    shape.setFillColor(Field[i][j].get_color());
                    shape.setPosition(sf::Vector2f(j * 4, i * 4));
                    window.draw(shape);
                }
        
        cursor_outline.setSize(sf::Vector2f(pen_size * 4, pen_size * 4));
        cursor_outline.setOutlineThickness(1);
        cursor_outline.setPosition(sf::Vector2f(cursor_pos_x * 4, cursor_pos_y * 4));
        window.draw(cursor_outline);

        window.display();
    }

    delete current_automata;

    return 0;
}